Savita Medlang 
Project 1: Web Proxy

Class list number 26

I used Google Chrome to test

To compile javac proxyd.java
To use, type java proxyd -port 5026